Give us an A please:
Some of the file locations might not work on your computer.
Specifically those coming from the Contact Us page and the links to the Contact us page.
Could you please change the href to the folder location you are using so that the links work. Thanks

We were not able to put the Contact Us, into the pages folder because it wouldn't keep the JavaScript syles done by our teammate.

